data class Position(val row: Int, val col: Int)
