abstract class GameObject {
    open lateinit var name: String
    abstract var position: Position
}
